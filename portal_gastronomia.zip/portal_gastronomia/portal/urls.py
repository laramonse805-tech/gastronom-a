from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login/", views.login_view, name="login"),
    path("registro/", views.registro_view, name="registro"),
    path("api/validar-rut/", views.validar_rut, name="validar_rut"),
]

for slug in views.PAGINAS:
    urlpatterns.append(path(f"{slug}/", views.panel, {"page": slug}, name=slug))
