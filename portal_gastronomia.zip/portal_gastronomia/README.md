# Portal-Gastronomía

Sistema de control de pañol gastronómico: **HTML + CSS + JavaScript + Python (Django)**.
Los usuarios (login y registro) y el inventario se guardan en el **localStorage** del navegador.

## Cómo ejecutarlo (PC o Termux)

```bash
pip install -r requirements.txt      # en Termux: pkg install python && pip install django
python manage.py runserver 0.0.0.0:8000
```

Abre http://127.0.0.1:8000/ en el navegador.

## Cuentas de ejemplo

| Rol                    | RUT          | Contraseña       |
|------------------------|--------------|------------------|
| Administrador/a        | 11111111-1   | Admin1234        |
| Encargado/a de cocina  | 22222222-2   | Cocina1234       |
| Estudiante             | 33333333-3   | Estudiante1234   |
| Docente                | 44444444-4   | Docente1234      |

También puedes crear una cuenta en `/registro/`.

## Estructura

- `config/` – configuración de Django.
- `portal/views.py`, `portal/urls.py` – páginas y endpoint `/api/validar-rut/` (Python).
- `portal/rut.py` – validación de RUT (módulo 11).
- `portal/templates/portal/` – login, registro y panel (HTML).
- `portal/static/portal/css/styles.css` – estilos.
- `portal/static/portal/js/app.js` – lógica, roles, localStorage.

## Claves de localStorage

`pg_usuarios`, `pg_sesion`, `pg_inventario`, `pg_movimientos`, `pg_entregas`,
`pg_prestamos`, `pg_catalogo`, `pg_reportes_estudiantes`, `pg_presupuesto`, `pg_consumo`.
Para reiniciar los datos: borra el localStorage del sitio.

## Imagen de la cocina (opcional)

Copia una foto como `portal/static/portal/img/cocina.jpg` y aparecerá de fondo (con el filtro azul) en la pantalla de registro.
